package tn.esprit.spring.entities;

public enum etatTrain {
    prevu, en_gare, en_route, annule;
}
