package tn.esprit.spring.entities;

public enum Ville {
tunis,RADES,EZZAHRA, SAKIETEZZIT,sfax,SOUSSE;
}
